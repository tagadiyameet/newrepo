// API Keys
const apiKey = '191d5a6d69251396ba3854082a68376a';  // OpenWeatherMap API key

// Global Variables
let currentUser = null;
let users = JSON.parse(localStorage.getItem('users')) || [];
migrateUsers(); // Ensure all users have the defaultLocation property

// DOM Content Loaded Event
document.addEventListener('DOMContentLoaded', function() {
    // Initialize city input autocomplete
    const cityInput = document.getElementById('cityInput');
    const citySuggestions = document.getElementById('citySuggestions');

    if (cityInput && citySuggestions) {
        cityInput.addEventListener('input', debounce(function() {
            const input = this.value.toLowerCase();
            citySuggestions.innerHTML = '';
            citySuggestions.style.display = 'none';

            if (input.length < 3) return;

            const url = `https://api.openweathermap.org/geo/1.0/direct?q=${input}&limit=5&appid=${apiKey}`;

            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.length > 0) {
                        const inputRect = cityInput.getBoundingClientRect();
                        citySuggestions.style.top = `${inputRect.bottom}px`;
                        citySuggestions.style.left = `${inputRect.left}px`;
                        citySuggestions.style.width = `${inputRect.width}px`;

                        citySuggestions.style.display = 'block';
                        data.forEach(city => {
                            const div = document.createElement('div');
                            div.textContent = city.name + ', ' + city.country;
                            div.style.padding = '5px';
                            div.style.cursor = 'pointer';
                            div.onclick = () => {
                                cityInput.value = city.name;
                                citySuggestions.style.display = 'none';
                                // Call appropriate function based on current page
                                if (window.location.href.includes('forecast.html')) {
                                    getForecast();
                                } else if (window.location.href.includes('historical.html')) {
                                    getHistoricalWeather();
                                } else if (window.location.href.includes('recommender.html')) {
                                    getRecommendations();
                                } else {
                                    getWeather();
                                }
                            };
                            citySuggestions.appendChild(div);
                        });
                    }
                })
                .catch(error => {
                    console.error('Error fetching city data:', error);
                });
        }, 300));
    }

    // Close suggestions when clicking outside
    document.addEventListener('click', function(event) {
        if (citySuggestions && !citySuggestions.contains(event.target) && event.target !== cityInput) {
            citySuggestions.style.display = 'none';
        }
    });

    // Check if user is logged in
    checkUserLogin();

    // Load page-specific content
    loadPageContent();
});

// Function to load page-specific content
function loadPageContent() {
    const path = window.location.pathname;
    
    if (path.includes('forecast.html')) {
        // Load forecast page content
        if (currentUser && currentUser.defaultLocation) {
            document.getElementById('cityInput').value = currentUser.defaultLocation;
            getForecast();
        }
    } else if (path.includes('historical.html')) {
        // Load historical page content
        if (currentUser && currentUser.defaultLocation) {
            document.getElementById('cityInput').value = currentUser.defaultLocation;
        }
        // Set max date to today and min date to 5 days ago
        const historicalDate = document.getElementById('historicalDate');
        if (historicalDate) {
            const today = new Date();
            const fiveDaysAgo = new Date();
            fiveDaysAgo.setDate(today.getDate() - 5);
            
            historicalDate.max = today.toISOString().split('T')[0];
            historicalDate.min = fiveDaysAgo.toISOString().split('T')[0];
            historicalDate.value = today.toISOString().split('T')[0];
        }
    } else if (path.includes('profile.html')) {
        // Load profile page content
        if (currentUser) {
            document.getElementById('loginRequired').style.display = 'none';
            document.getElementById('profileContainer').style.display = 'block';
            
            // Display user information
            document.getElementById('profileUsername').textContent = currentUser.username;
            document.getElementById('accountCreated').textContent = 'N/A'; // Could add creation date to user object
            
            // Set temperature unit preference
            const unitRadios = document.querySelectorAll('input[name="temperatureUnit"]');
            unitRadios.forEach(radio => {
                if (radio.value === currentUser.preferences.temperatureUnit) {
                    radio.checked = true;
                }
            });
            
            // Display default location
            if (currentUser.defaultLocation) {
                document.getElementById('defaultLocationDisplay').textContent = currentUser.defaultLocation;
            }
            
            // Display favorite locations
            updateProfileFavoritesList();
        }
    } else if (path.includes('recommender.html')) {
        // Load recommender page content
        if (currentUser) {
            document.getElementById('loginRequired').style.display = 'none';
            document.getElementById('activityPreferences').style.display = 'block';
            
            if (currentUser.defaultLocation) {
                document.getElementById('cityInput').value = currentUser.defaultLocation;
                getRecommendations();
            }
        }
    } else {
        // Main page (index.html)
        if (currentUser && currentUser.defaultLocation) {
            document.getElementById('cityInput').value = currentUser.defaultLocation;
            getWeather();
        }
    }
}

// User Authentication Functions
function migrateUsers() {
    users = users.map(user => {
        if (!user.defaultLocation) {
            user.defaultLocation = null;
        }
        if (!user.preferences) {
            user.preferences = {
                temperatureUnit: 'Celsius'
            };
        }
        return user;
    });
    localStorage.setItem('users', JSON.stringify(users));
}

function register() {
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;

    if (!username || !password) {
        alert("Please enter a username and password.");
        return;
    }

    // Check if the user already exists
    if (users.some(user => user.username === username)) {
        alert("Username already exists. Please choose another.");
        return;
    }

    // Create a new user
    const newUser = {
        username: username,
        password: password, // In a real app, you should hash the password!
        preferences: {
            temperatureUnit: 'Celsius' // Default preference
        },
        defaultLocation: null // Default location
    };

    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    alert("Registration successful. Please log in.");
    closeModal('registerModal');
}

function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // Update UI elements
        updateUIForLoggedInUser();
        
        alert("Login successful.");
        closeModal('loginModal');
        
        // Load default location weather if set
        if (currentUser.defaultLocation) {
            document.getElementById('cityInput').value = currentUser.defaultLocation;
            
            // Call appropriate function based on current page
            const path = window.location.pathname;
            if (path.includes('forecast.html')) {
                getForecast();
            } else if (path.includes('historical.html')) {
                // Just set the input, user needs to select date
            } else if (path.includes('recommender.html')) {
                getRecommendations();
            } else if (path.includes('profile.html')) {
                loadPageContent();
            } else {
                getWeather();
            }
        }
    } else {
        alert("Invalid username or password.");
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    
    // Update UI elements
    updateUIForLoggedOutUser();
    
    // Reset the city input field and clear results
    document.getElementById('cityInput').value = '';
    
    // Hide weather-related elements
    const weatherElements = ['weatherResult', 'forecastResult', 'aqiResult', 'uvIndexResult', 'localTime', 'historicalResult', 'recommendationsContainer', 'weatherSummary'];
    weatherElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'none';
    });
    
    // Show registration benefits
    const registrationBenefits = document.getElementById('registrationBenefits');
    if (registrationBenefits) registrationBenefits.style.display = 'block';
    
    // Show login required on specific pages
    const loginRequired = document.getElementById('loginRequired');
    if (loginRequired) loginRequired.style.display = 'block';
    
    // Hide profile container
    const profileContainer = document.getElementById('profileContainer');
    if (profileContainer) profileContainer.style.display = 'none';
    
    // Reset background to default
    updateBackground();
    
    alert("Logged out successfully.");
}

function checkUserLogin() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        updateUIForLoggedInUser();
    }
}

function updateUIForLoggedInUser() {
    // Hide login/register buttons
    const loginButton = document.querySelector('#userSection button[onclick="showLoginModal()"]');
    const registerButton = document.querySelector('#userSection button[onclick="showRegisterModal()"]');
    if (loginButton) loginButton.style.display = 'none';
    if (registerButton) registerButton.style.display = 'none';
    
    // Show profile section
    const profileSection = document.getElementById('profileSection');
    if (profileSection) profileSection.style.display = 'flex';
    
    // Show user-only elements
    const userOnlyElements = ['unitToggle', 'defaultLocation', 'locationButton'];
    userOnlyElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'block';
    });
    
    // Display welcome message
    const welcomeMessage = document.getElementById('welcomeMessage');
    if (welcomeMessage) {
        welcomeMessage.textContent = `Welcome, ${currentUser.username}!`;
        welcomeMessage.style.display = 'block';
    }
    
    // Display username
    const loggedInUser = document.getElementById('loggedInUser');
    if (loggedInUser) loggedInUser.textContent = currentUser.username;
    
    // Hide registration benefits
    const registrationBenefits = document.getElementById('registrationBenefits');
    if (registrationBenefits) registrationBenefits.style.display = 'none';
    
    // Hide login required on specific pages
    const loginRequired = document.getElementById('loginRequired');
    if (loginRequired) loginRequired.style.display = 'none';
    
    // Show profile container
    const profileContainer = document.getElementById('profileContainer');
    if (profileContainer) profileContainer.style.display = 'block';
    
    // Show activity preferences
    const activityPreferences = document.getElementById('activityPreferences');
    if (activityPreferences) activityPreferences.style.display = 'block';
}

function updateUIForLoggedOutUser() {
    // Show login/register buttons
    const loginButton = document.querySelector('#userSection button[onclick="showLoginModal()"]');
    const registerButton = document.querySelector('#userSection button[onclick="showRegisterModal()"]');
    if (loginButton) loginButton.style.display = 'inline-block';
    if (registerButton) registerButton.style.display = 'inline-block';
    
    // Hide profile section
    const profileSection = document.getElementById('profileSection');
    if (profileSection) profileSection.style.display = 'none';
    
    // Hide dropdown menu
    const dropdownMenu = document.getElementById('dropdownMenu');
    if (dropdownMenu) dropdownMenu.style.display = 'none';
    
    // Hide user-only elements
    const userOnlyElements = ['unitToggle', 'defaultLocation', 'locationButton'];
    userOnlyElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'none';
    });
    
    // Hide welcome message
    const welcomeMessage = document.getElementById('welcomeMessage');
    if (welcomeMessage) welcomeMessage.style.display = 'none';
}

// Weather API Functions
function getWeather() {
    const city = document.getElementById('cityInput').value;
    if (!city) {
        alert("Please enter a city name.");
        return;
    }

    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';

    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(weatherUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayWeather(data);
            
            // Get additional data if user is logged in
            if (currentUser) {
                getAirQuality(data.coord.lat, data.coord.lon);
                getUVIndex(data.coord.lat, data.coord.lon);
                getLocalTime(data.coord.lat, data.coord.lon, data.name, data.sys.country);
            }
            
            // Update background based on weather
            updateBackground(data.weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            alert("Error fetching weather data. Please try again.");
        })
        .finally(() => {
            if (loading) loading.style.display = 'none';
        });
}

function displayWeather(data) {
    const weatherResult = document.getElementById('weatherResult');
    const temperature = document.getElementById('temperature');
    const temperatureUnit = document.getElementById('temperatureUnit');
    const description = document.getElementById('description');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('windSpeed');
    const visibility = document.getElementById('visibility');
    const sunrise = document.getElementById('sunrise');
    const sunset = document.getElementById('sunset');
    const country = document.getElementById('country');

    // Convert temperature if user prefers Fahrenheit
    let temp = data.main.temp;
    let unit = 'C';
    if (currentUser && currentUser.preferences.temperatureUnit === 'Fahrenheit') {
        temp = (temp * 9/5) + 32;
        unit = 'F';
    }

    temperature.textContent = Math.round(temp);
    temperatureUnit.textContent = unit;
    description.textContent = data.weather[0].description;
    humidity.textContent = data.main.humidity;
    windSpeed.textContent = data.wind.speed;
    visibility.textContent = data.visibility;
    
    // Format sunrise and sunset times
    const sunriseDate = new Date(data.sys.sunrise * 1000);
    const sunsetDate = new Date(data.sys.sunset * 1000);
    sunrise.textContent = sunriseDate.toLocaleTimeString();
    sunset.textContent = sunsetDate.toLocaleTimeString();
    
    country.textContent = data.sys.country;

    weatherResult.style.display = 'block';
    
    // Show default location button for logged in users
    const defaultLocation = document.getElementById('defaultLocation');
    if (defaultLocation && currentUser) {
        defaultLocation.style.display = 'block';
    }
}

function getAirQuality(lat, lon) {
    const aqiUrl = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`;

    fetch(aqiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayAirQuality(data);
        })
        .catch(error => {
            console.error('Error fetching air quality data:', error);
        });
}

function displayAirQuality(data) {
    const aqiResult = document.getElementById('aqiResult');
    const aqiValue = document.getElementById('aqiValue');
    const aqiCategory = document.getElementById('aqiCategory');
    const healthTip = document.getElementById('healthTip');

    const aqi = data.list[0].main.aqi;
    
    // AQI categories and health tips
    const aqiInfo = {
        1: { category: "Good", tip: "Air quality is considered satisfactory, and air pollution poses little or no risk." },
        2: { category: "Fair", tip: "Air quality is acceptable; however, for some pollutants there may be a moderate health concern for a very small number of people." },
        3: { category: "Moderate", tip: "Members of sensitive groups may experience health effects. The general public is not likely to be affected." },
        4: { category: "Poor", tip: "Everyone may begin to experience health effects; members of sensitive groups may experience more serious health effects." },
        5: { category: "Very Poor", tip: "Health warnings of emergency conditions. The entire population is more likely to be affected." }
    };

    aqiValue.textContent = `AQI: ${aqi}`;
    aqiCategory.textContent = `Category: ${aqiInfo[aqi].category}`;
    healthTip.textContent = `Health Tip: ${aqiInfo[aqi].tip}`;

    aqiResult.style.display = 'block';
}

function getUVIndex(lat, lon) {
    // OpenWeatherMap's OneCall API for UV Index
    const uvUrl = `https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&exclude=minutely,hourly,daily,alerts&appid=${apiKey}`;

    fetch(uvUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.current && data.current.uvi !== undefined) {
                displayUVIndex(data.current.uvi);
            }
        })
        .catch(error => {
            console.error('Error fetching UV index data:', error);
        });
}

function displayUVIndex(uvi) {
    const uvIndexResult = document.getElementById('uvIndexResult');
    const uvIndexValue = document.getElementById('uvIndexValue');
    const uvIndexCategory = document.getElementById('uvIndexCategory');
    const uvIndexTip = document.getElementById('uvIndexTip');

    // UV Index categories and recommendations
    let category, tip;
    if (uvi < 3) {
        category = "Low";
        tip = "Wear sunglasses on bright days. If you burn easily, cover up and use broad spectrum SPF 30+ sunscreen.";
    } else if (uvi < 6) {
        category = "Moderate";
        tip = "Stay in shade near midday when the sun is strongest. Cover up and use broad spectrum SPF 30+ sunscreen.";
    } else if (uvi < 8) {
        category = "High";
        tip = "Reduce time in the sun between 10 a.m. and 4 p.m. Cover up, wear a hat and sunglasses, and use SPF 30+ sunscreen.";
    } else if (uvi < 11) {
        category = "Very High";
        tip = "Minimize sun exposure between 10 a.m. and 4 p.m. Cover up, wear a hat and sunglasses, and use SPF 30+ sunscreen.";
    } else {
        category = "Extreme";
        tip = "Try to avoid sun exposure between 10 a.m. and 4 p.m. Cover up, wear a hat and sunglasses, and use SPF 30+ sunscreen.";
    }

    uvIndexValue.textContent = `UV Index: ${uvi.toFixed(1)}`;
    uvIndexCategory.textContent = `Category: ${category}`;
    uvIndexTip.textContent = `Recommendation: ${tip}`;

    uvIndexResult.style.display = 'block';
}

function getLocalTime(lat, lon, city, country) {
    // Use timezone API to get local time
    const timezoneUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`;

    fetch(timezoneUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayLocalTime(data.timezone, city, country);
        })
        .catch(error => {
            console.error('Error fetching timezone data:', error);
        });
}

function displayLocalTime(timezoneOffset, city, country) {
    const localTimeElement = document.getElementById('localTime');
    
    // Update local time every second
    function updateTime() {
        const now = new Date();
        const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
        const localTime = new Date(utc + (1000 * timezoneOffset));
        
        localTimeElement.innerHTML = `
            <h3>Local Time</h3>
            <p>${city}, ${country}</p>
            <div class="time-circle">${localTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
            <p>${localTime.toLocaleDateString()}</p>
        `;
    }
    
    updateTime();
    setInterval(updateTime, 1000);
    
    localTimeElement.style.display = 'block';
}

function getForecast() {
    const city = document.getElementById('cityInput').value;
    if (!city) {
        alert("Please enter a city name.");
        return;
    }

    if (!currentUser) {
        alert("Please log in to view the forecast.");
        return;
    }

    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';

    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;

    fetch(forecastUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayForecast(data);
            
            // Update background based on current weather
            updateBackground(data.list[0].weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching forecast data:', error);
            alert("Error fetching forecast data. Please try again.");
        })
        .finally(() => {
            if (loading) loading.style.display = 'none';
        });
}

function displayForecast(data) {
    const forecastResult = document.getElementById('forecastResult');
    const forecastContainer = document.getElementById('forecastContainer');
    const cityName = document.getElementById('cityName');
    
    if (!forecastResult || !forecastContainer || !cityName) return;
    
    cityName.textContent = data.city.name;
    forecastContainer.innerHTML = '';
    
    // Group forecast data by day
    const dailyForecasts = {};
    
    data.list.forEach(item => {
        const date = new Date(item.dt * 1000);
        const day = date.toLocaleDateString();
        
        if (!dailyForecasts[day]) {
            dailyForecasts[day] = {
                date: date,
                temps: [],
                icons: [],
                descriptions: []
            };
        }
        
        dailyForecasts[day].temps.push(item.main.temp);
        dailyForecasts[day].icons.push(item.weather[0].icon);
        dailyForecasts[day].descriptions.push(item.weather[0].description);
    });
    
    // Create forecast cards for each day
    Object.values(dailyForecasts).slice(0, 5).forEach(forecast => {
        // Calculate average temperature
        const avgTemp = forecast.temps.reduce((sum, temp) => sum + temp, 0) / forecast.temps.length;
        
        // Convert temperature if user prefers Fahrenheit
        let temp = avgTemp;
        let unit = '°C';
        if (currentUser && currentUser.preferences.temperatureUnit === 'Fahrenheit') {
            temp = (temp * 9/5) + 32;
            unit = '°F';
        }
        
        // Get most frequent icon and description
        const iconCounts = {};
        forecast.icons.forEach(icon => {
            iconCounts[icon] = (iconCounts[icon] || 0) + 1;
        });
        const mostFrequentIcon = Object.entries(iconCounts).sort((a, b) => b[1] - a[1])[0][0];
        
        const descriptionCounts = {};
        forecast.descriptions.forEach(desc => {
            descriptionCounts[desc] = (descriptionCounts[desc] || 0) + 1;
        });
        const mostFrequentDescription = Object.entries(descriptionCounts).sort((a, b) => b[1] - a[1])[0][0];
        
        // Create forecast card
        const forecastDay = document.createElement('div');
        forecastDay.className = 'forecast-day';
        forecastDay.innerHTML = `
            <h3>${forecast.date.toLocaleDateString(undefined, { weekday: 'long' })}</h3>
            <p>${forecast.date.toLocaleDateString()}</p>
            <img src="https://openweathermap.org/img/wn/${mostFrequentIcon}@2x.png" alt="${mostFrequentDescription}">
            <p>${mostFrequentDescription}</p>
            <p>${Math.round(temp)}${unit}</p>
        `;
        
        forecastContainer.appendChild(forecastDay);
    });
    
    forecastResult.style.display = 'block';
}

function getHistoricalWeather() {
    const city = document.getElementById('cityInput').value;
    const dateInput = document.getElementById('historicalDate');
    
    if (!city) {
        alert("Please enter a city name.");
        return;
    }
    
    if (!dateInput || !dateInput.value) {
        alert("Please select a date.");
        return;
    }
    
    if (!currentUser) {
        alert("Please log in to view historical weather data.");
        return;
    }
    
    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';
    
    // First get coordinates for the city
    const geoUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=${apiKey}`;
    
    fetch(geoUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.length === 0) {
                throw new Error('City not found');
            }
            
            const lat = data[0].lat;
            const lon = data[0].lon;
            
            // Convert date to Unix timestamp
            const selectedDate = new Date(dateInput.value);
            const timestamp = Math.floor(selectedDate.getTime() / 1000);
            
            // Use OpenWeatherMap's historical data API
            return fetch(`https://api.openweathermap.org/data/3.0/onecall/timemachine?lat=${lat}&lon=${lon}&dt=${timestamp}&appid=${apiKey}&units=metric`);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayHistoricalWeather(data, city);
            
            // Update background based on weather
            updateBackground(data.data[0].weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching historical weather data:', error);
            alert("Error fetching historical weather data. Please try again. Note that historical data is only available for the past 5 days.");
        })
        .finally(() => {
            if (loading) loading.style.display = 'none';
        });
}

function displayHistoricalWeather(data, city) {
    const historicalResult = document.getElementById('historicalResult');
    const historicalCity = document.getElementById('historicalCity');
    const historicalDateDisplay = document.getElementById('historicalDateDisplay');
    const temperature = document.getElementById('temperature');
    const temperatureUnit = document.getElementById('temperatureUnit');
    const description = document.getElementById('description');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('windSpeed');
    const pressure = document.getElementById('pressure');
    
    if (!historicalResult || !historicalCity || !historicalDateDisplay || !temperature || 
        !temperatureUnit || !description || !humidity || !windSpeed || !pressure) {
        return;
    }
    
    const weatherData = data.data[0];
    
    // Convert temperature if user prefers Fahrenheit
    let temp = weatherData.temp;
    let unit = 'C';
    if (currentUser && currentUser.preferences.temperatureUnit === 'Fahrenheit') {
        temp = (temp * 9/5) + 32;
        unit = 'F';
    }
    
    const date = new Date(weatherData.dt * 1000);
    
    historicalCity.textContent = city;
    historicalDateDisplay.textContent = date.toLocaleDateString();
    temperature.textContent = Math.round(temp);
    temperatureUnit.textContent = unit;
    description.textContent = weatherData.weather[0].description;
    humidity.textContent = weatherData.humidity;
    windSpeed.textContent = weatherData.wind_speed;
    pressure.textContent = weatherData.pressure;
    
    historicalResult.style.display = 'block';
}

function getRecommendations() {
    const city = document.getElementById('cityInput').value;
    
    if (!city) {
        alert("Please enter a city name.");
        return;
    }
    
    if (!currentUser) {
        alert("Please log in to use the activity recommender.");
        return;
    }
    
    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';
    
    // First get current weather for the city
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
    
    fetch(weatherUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayWeatherSummary(data);
            generateActivityRecommendations(data);
            
            // Update background based on weather
            updateBackground(data.weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching weather data for recommendations:', error);
            alert("Error fetching weather data. Please try again.");
        })
        .finally(() => {
            if (loading) loading.style.display = 'none';
        });
}

function displayWeatherSummary(data) {
    const weatherSummary = document.getElementById('weatherSummary');
    const cityName = document.getElementById('cityName');
    const temperature = document.getElementById('temperature');
    const temperatureUnit = document.getElementById('temperatureUnit');
    const description = document.getElementById('description');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('windSpeed');
    
    if (!weatherSummary || !cityName || !temperature || !temperatureUnit || 
        !description || !humidity || !windSpeed) {
        return;
    }
    
    // Convert temperature if user prefers Fahrenheit
    let temp = data.main.temp;
    let unit = 'C';
    if (currentUser && currentUser.preferences.temperatureUnit === 'Fahrenheit') {
        temp = (temp * 9/5) + 32;
        unit = 'F';
    }
    
    cityName.textContent = data.name;
    temperature.textContent = Math.round(temp);
    temperatureUnit.textContent = unit;
    description.textContent = data.weather[0].description;
    humidity.textContent = data.main.humidity;
    windSpeed.textContent = data.wind.speed;
    
    weatherSummary.style.display = 'block';
}

function generateActivityRecommendations(weatherData) {
    const recommendationsContainer = document.getElementById('recommendationsContainer');
    const activityRecommendations = document.getElementById('activityRecommendations');
    
    if (!recommendationsContainer || !activityRecommendations || !window.activityDatabase) {
        console.error('Missing elements or activity database not loaded');
        return;
    }
    
    // Get user preferences
    const outdoorActivities = document.getElementById('outdoorActivities').checked;
    const indoorActivities = document.getElementById('indoorActivities').checked;
    const minIntensity = parseInt(document.getElementById('minIntensity').value);
    const maxIntensity = parseInt(document.getElementById('maxIntensity').value);
    
    // Filter activities based on weather and user preferences
    const filteredActivities = window.activityDatabase.filter(activity => {
        // Filter by category
        if (activity.category === 'outdoor' && !outdoorActivities) return false;
        if (activity.category === 'indoor' && !indoorActivities) return false;
        
        // Filter by intensity
        if (activity.intensity < minIntensity || activity.intensity > maxIntensity) return false;
        
        // Filter by weather conditions
        const weatherCondition = weatherData.weather[0].description.toLowerCase();
        const isWeatherSuitable = activity.weatherConditions.some(condition => 
            weatherCondition.includes(condition) || condition === 'clouds' && weatherCondition.includes('cloud')
        );
        
        // Check temperature
        const isTemperatureSuitable = 
            weatherData.main.temp >= activity.temperatureRange.min && 
            weatherData.main.temp <= activity.temperatureRange.max;
        
        // Check wind speed if applicable
        const isWindSpeedSuitable = activity.windSpeedMax === undefined || 
            weatherData.wind.speed <= activity.windSpeedMax;
        
        // Check minimum wind speed if applicable
        const isWindSpeedMinSuitable = activity.windSpeedMin === undefined || 
            weatherData.wind.speed >= activity.windSpeedMin;
        
        return isWeatherSuitable && isTemperatureSuitable && isWindSpeedSuitable && isWindSpeedMinSuitable;
    });
    
    // Display recommendations
    activityRecommendations.innerHTML = '';
    
    if (filteredActivities.length === 0) {
        activityRecommendations.innerHTML = '<p>No activities match the current weather conditions and your preferences. Try adjusting your preferences.</p>';
    } else {
        // Sort activities by suitability (simple algorithm)
        const sortedActivities = filteredActivities.sort((a, b) => {
            // Prioritize activities with more matching weather conditions
            const aMatchCount = a.weatherConditions.filter(condition => 
                weatherData.weather[0].description.toLowerCase().includes(condition)
            ).length;
            
            const bMatchCount = b.weatherConditions.filter(condition => 
                weatherData.weather[0].description.toLowerCase().includes(condition)
            ).length;
            
            return bMatchCount - aMatchCount;
        });
        
        // Display top 6 activities
        sortedActivities.slice(0, 6).forEach(activity => {
            const activityCard = document.createElement('div');
            activityCard.className = 'activity-card';
            
            const tagsHtml = activity.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
            
            activityCard.innerHTML = `
                <h3>${activity.name}</h3>
                <p class="description">${activity.description}</p>
                <p>Category: ${activity.category === 'outdoor' ? 'Outdoor' : 'Indoor'}</p>
                <p>Intensity: ${'★'.repeat(activity.intensity)}${'☆'.repeat(5 - activity.intensity)}</p>
                <p>Duration: ${activity.duration} minutes</p>
                <div class="tags">${tagsHtml}</div>
            `;
            
            activityRecommendations.appendChild(activityCard);
        });
    }
    
    recommendationsContainer.style.display = 'block';
}

// User Preferences Functions
function updatePreferences() {
    if (!currentUser) return;
    
    const temperatureUnit = document.querySelector('input[name="temperatureUnit"]:checked').value;
    
    currentUser.preferences.temperatureUnit = temperatureUnit;
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].preferences = currentUser.preferences;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    // Refresh weather display with new unit
    const path = window.location.pathname;
    if (path.includes('forecast.html')) {
        getForecast();
    } else if (path.includes('historical.html')) {
        getHistoricalWeather();
    } else if (path.includes('recommender.html')) {
        getRecommendations();
    } else {
        getWeather();
    }
}

function setDefaultLocation() {
    if (!currentUser) return;
    
    const city = document.getElementById('cityInput').value;
    if (!city) {
        alert("Please enter a city name first.");
        return;
    }
    
    currentUser.defaultLocation = city;
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].defaultLocation = city;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    alert(`${city} has been set as your default location.`);
    
    // Update profile page if on it
    const defaultLocationDisplay = document.getElementById('defaultLocationDisplay');
    if (defaultLocationDisplay) {
        defaultLocationDisplay.textContent = city;
    }
}

function updateDefaultLocation() {
    if (!currentUser) return;
    
    const city = document.getElementById('defaultLocationInput').value;
    if (!city) {
        alert("Please enter a city name.");
        return;
    }
    
    currentUser.defaultLocation = city;
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].defaultLocation = city;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    document.getElementById('defaultLocationDisplay').textContent = city;
    document.getElementById('defaultLocationInput').value = '';
    
    alert(`${city} has been set as your default location.`);
}

// Favorites Functions
function showFavCities() {
    const favCitiesModal = document.getElementById('favCitiesModal');
    favCitiesModal.style.display = 'block';
    updateFavCitiesList();
}

function toggleFavCityActions() {
    const favCityActions = document.getElementById('favCityActions');
    favCityActions.style.display = favCityActions.style.display === 'none' ? 'block' : 'none';
}

function addFavCity() {
    const cityInput = document.getElementById('favCityInput');
    const city = cityInput.value.trim();
    
    if (!city) {
        alert('Please enter a city name.');
        return;
    }
    
    if (!currentUser) {
        alert('Please log in to add favorite cities.');
        return;
    }
    
    // Initialize favorites array if it doesn't exist
    if (!currentUser.favorites) {
        currentUser.favorites = [];
    }
    
    // Check if city is already in favorites
    if (currentUser.favorites.includes(city)) {
        alert('City already in favorites.');
        return;
    }
    
    // Add to favorites
    currentUser.favorites.push(city);
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].favorites = currentUser.favorites;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    cityInput.value = '';
    updateFavCitiesList();
    
    // Also update profile favorites list if on profile page
    updateProfileFavoritesList();
}

function removeFavCity(city) {
    if (!currentUser || !currentUser.favorites) return;
    
    // Remove from favorites
    currentUser.favorites = currentUser.favorites.filter(c => c !== city);
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].favorites = currentUser.favorites;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    updateFavCitiesList();
    
    // Also update profile favorites list if on profile page
    updateProfileFavoritesList();
}

function updateFavCitiesList() {
    const favCitiesList = document.getElementById('favCitiesList');
    if (!favCitiesList) return;
    
    favCitiesList.innerHTML = '';
    
    if (!currentUser || !currentUser.favorites || currentUser.favorites.length === 0) {
        favCitiesList.innerHTML = '<li>No favorite cities added yet.</li>';
        return;
    }
    
    currentUser.favorites.forEach(city => {
        const li = document.createElement('li');
        li.textContent = city;
        
        // Add click handler to show weather for this city
        li.style.cursor = 'pointer';
        li.onclick = function(e) {
            if (e.target !== this) return; // Ignore clicks on child elements
            
            document.getElementById('cityInput').value = city;
            closeModal('favCitiesModal');
            
            // Call appropriate function based on current page
            const path = window.location.pathname;
            if (path.includes('forecast.html')) {
                getForecast();
            } else if (path.includes('historical.html')) {
                // Just set the input, user needs to select date
            } else if (path.includes('recommender.html')) {
                getRecommendations();
            } else {
                getWeather();
            }
        };
        
        // Add remove button
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.onclick = function(e) {
            e.stopPropagation(); // Prevent triggering the li click
            removeFavCity(city);
        };
        
        li.appendChild(removeBtn);
        favCitiesList.appendChild(li);
    });
}

function updateProfileFavoritesList() {
    const profileFavoritesList = document.getElementById('profileFavoritesList');
    if (!profileFavoritesList) return;
    
    profileFavoritesList.innerHTML = '';
    
    if (!currentUser || !currentUser.favorites || currentUser.favorites.length === 0) {
        profileFavoritesList.innerHTML = '<li>No favorite cities added yet.</li>';
        return;
    }
    
    currentUser.favorites.forEach(city => {
        const li = document.createElement('li');
        
        const citySpan = document.createElement('span');
        citySpan.textContent = city;
        li.appendChild(citySpan);
        
        // Add remove button
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.onclick = function() {
            removeFavCity(city);
        };
        
        li.appendChild(removeBtn);
        profileFavoritesList.appendChild(li);
    });
}

function addToFavorites() {
    const cityInput = document.getElementById('newFavoriteInput');
    const city = cityInput.value.trim();
    
    if (!city) {
        alert('Please enter a city name.');
        return;
    }
    
    if (!currentUser) {
        alert('Please log in to add favorite cities.');
        return;
    }
    
    // Initialize favorites array if it doesn't exist
    if (!currentUser.favorites) {
        currentUser.favorites = [];
    }
    
    // Check if city is already in favorites
    if (currentUser.favorites.includes(city)) {
        alert('City already in favorites.');
        return;
    }
    
    // Add to favorites
    currentUser.favorites.push(city);
    
    // Update in users array
    const userIndex = users.findIndex(user => user.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex].favorites = currentUser.favorites;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    cityInput.value = '';
    updateProfileFavoritesList();
}

// Geolocation Functions
function getLocation() {
    if (navigator.geolocation) {
        const loading = document.getElementById('loading');
        if (loading) loading.style.display = 'block';
        
        navigator.geolocation.getCurrentPosition(
            position => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                getWeatherByCoords(lat, lon);
            },
            error => {
                console.error('Geolocation error:', error);
                alert('Unable to retrieve your location. Please enter a city name.');
                if (loading) loading.style.display = 'none';
            }
        );
    } else {
        alert('Geolocation is not supported by this browser. Please enter a city name.');
    }
}

function getLocationForForecast() {
    if (navigator.geolocation) {
        const loading = document.getElementById('loading');
        if (loading) loading.style.display = 'block';
        
        navigator.geolocation.getCurrentPosition(
            position => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                getForecastByCoords(lat, lon);
            },
            error => {
                console.error('Geolocation error:', error);
                alert('Unable to retrieve your location. Please enter a city name.');
                if (loading) loading.style.display = 'none';
            }
        );
    } else {
        alert('Geolocation is not supported by this browser. Please enter a city name.');
    }
}

function getLocationForHistorical() {
    if (navigator.geolocation) {
        const loading = document.getElementById('loading');
        if (loading) loading.style.display = 'block';
        
        navigator.geolocation.getCurrentPosition(
            position => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                getHistoricalWeatherByCoords(lat, lon);
            },
            error => {
                console.error('Geolocation error:', error);
                alert('Unable to retrieve your location. Please enter a city name.');
                if (loading) loading.style.display = 'none';
            }
        );
    } else {
        alert('Geolocation is not supported by this browser. Please enter a city name.');
    }
}

function getLocationForRecommendations() {
    if (navigator.geolocation) {
        const loading = document.getElementById('loading');
        if (loading) loading.style.display = 'block';
        
        navigator.geolocation.getCurrentPosition(
            position => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                getRecommendationsByCoords(lat, lon);
            },
            error => {
                console.error('Geolocation error:', error);
                alert('Unable to retrieve your location. Please enter a city name.');
                if (loading) loading.style.display = 'none';
            }
        );
    } else {
        alert('Geolocation is not supported by this browser. Please enter a city name.');
    }
}

function getWeatherByCoords(lat, lon) {
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    
    fetch(weatherUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Update city input with the retrieved location name
            document.getElementById('cityInput').value = data.name;
            
            displayWeather(data);
            
            // Get additional data if user is logged in
            if (currentUser) {
                getAirQuality(lat, lon);
                getUVIndex(lat, lon);
                getLocalTime(lat, lon, data.name, data.sys.country);
            }
            
            // Update background based on weather
            updateBackground(data.weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            alert("Error fetching weather data. Please try again.");
        })
        .finally(() => {
            const loading = document.getElementById('loading');
            if (loading) loading.style.display = 'none';
        });
}

function getForecastByCoords(lat, lon) {
    const reverseGeoUrl = `https://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&limit=1&appid=${apiKey}`;
    
    fetch(reverseGeoUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(geoData => {
            if (geoData.length === 0) {
                throw new Error('Location not found');
            }
            
            // Update city input with the retrieved location name
            document.getElementById('cityInput').value = geoData[0].name;
            
            const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
            return fetch(forecastUrl);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayForecast(data);
            
            // Update background based on current weather
            updateBackground(data.list[0].weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching forecast data:', error);
            alert("Error fetching forecast data. Please try again.");
        })
        .finally(() => {
            const loading = document.getElementById('loading');
            if (loading) loading.style.display = 'none';
        });
}

function getHistoricalWeatherByCoords(lat, lon) {
    const reverseGeoUrl = `https://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&limit=1&appid=${apiKey}`;
    
    fetch(reverseGeoUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(geoData => {
            if (geoData.length === 0) {
                throw new Error('Location not found');
            }
            
            // Update city input with the retrieved location name
            document.getElementById('cityInput').value = geoData[0].name;
            
            const dateInput = document.getElementById('historicalDate');
            if (!dateInput || !dateInput.value) {
                alert("Please select a date.");
                throw new Error('Date not selected');
            }
            
            // Convert date to Unix timestamp
            const selectedDate = new Date(dateInput.value);
            const timestamp = Math.floor(selectedDate.getTime() / 1000);
            
            // Use OpenWeatherMap's historical data API
            return fetch(`https://api.openweathermap.org/data/3.0/onecall/timemachine?lat=${lat}&lon=${lon}&dt=${timestamp}&appid=${apiKey}&units=metric`);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayHistoricalWeather(data, document.getElementById('cityInput').value);
            
            // Update background based on weather
            updateBackground(data.data[0].weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching historical weather data:', error);
            alert("Error fetching historical weather data. Please try again. Note that historical data is only available for the past 5 days.");
        })
        .finally(() => {
            const loading = document.getElementById('loading');
            if (loading) loading.style.display = 'none';
        });
}

function getRecommendationsByCoords(lat, lon) {
    const reverseGeoUrl = `https://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&limit=1&appid=${apiKey}`;
    
    fetch(reverseGeoUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(geoData => {
            if (geoData.length === 0) {
                throw new Error('Location not found');
            }
            
            // Update city input with the retrieved location name
            document.getElementById('cityInput').value = geoData[0].name;
            
            const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
            return fetch(weatherUrl);
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displayWeatherSummary(data);
            generateActivityRecommendations(data);
            
            // Update background based on weather
            updateBackground(data.weather[0].main);
        })
        .catch(error => {
            console.error('Error fetching weather data for recommendations:', error);
            alert("Error fetching weather data. Please try again.");
        })
        .finally(() => {
            const loading = document.getElementById('loading');
            if (loading) loading.style.display = 'none';
        });
}

// UI Helper Functions
function showLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
}

function showRegisterModal() {
    document.getElementById('registerModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function toggleMenu() {
    const dropdownMenu = document.getElementById('dropdownMenu');
    dropdownMenu.style.display = dropdownMenu.style.display === 'none' ? 'block' : 'none';
}

function updateBackground(weatherCondition = '') {
    let backgroundImage = 'default.jpg';
    
    if (weatherCondition) {
        weatherCondition = weatherCondition.toLowerCase();
        
        if (weatherCondition.includes('clear')) {
            backgroundImage = 'clear.jpg';
        } else if (weatherCondition.includes('few clouds')) {
            backgroundImage = 'few_clouds.jpg';
        } else if (weatherCondition.includes('scattered clouds')) {
            backgroundImage = 'scattered.jpg';
        } else if (weatherCondition.includes('broken clouds') || weatherCondition.includes('overcast')) {
            backgroundImage = 'broken_clouds.jpg';
        } else if (weatherCondition.includes('shower rain') || weatherCondition.includes('rain')) {
            backgroundImage = 'rain.jpg';
        } else if (weatherCondition.includes('thunderstorm')) {
            backgroundImage = 'thunderstorm.jpg';
        } else if (weatherCondition.includes('snow')) {
            backgroundImage = 'snow.jpg';
        } else if (weatherCondition.includes('mist') || weatherCondition.includes('fog')) {
            backgroundImage = 'mist.jpg';
        } else if (weatherCondition.includes('drizzle')) {
            backgroundImage = 'drizzle.jpg';
        } else if (weatherCondition.includes('smoke')) {
            backgroundImage = 'smoke.jpg';
        } else if (weatherCondition.includes('haze')) {
            backgroundImage = 'haze.jpg';
        }
    }
    
    // Determine the correct path based on current page
    let imagePath;
    if (window.location.pathname.includes('/pages/')) {
        imagePath = `../images/${backgroundImage}`;
    } else {
        imagePath = `images/${backgroundImage}`;
    }
    
    document.body.style.backgroundImage = `url('${imagePath}')`;
}

function updateRecommendations() {
    const city = document.getElementById('cityInput').value;
    if (!city) {
        alert("Please enter a city name first.");
        return;
    }
    
    getRecommendations();
}

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

// Window load event to check login status
window.addEventListener('load', function() {
    checkUserLogin();
    loadPageContent();
});
